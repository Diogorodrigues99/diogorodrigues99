import React, { useState } from 'react';
import { Menu } from 'lucide-react';

export default function Navigation() {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <nav className="bg-white shadow-lg">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center h-16">
          <a href="#" className="text-xl font-bold text-blue-900">Sergio Klem</a>
          
          <div className="hidden md:flex space-x-8">
            <a href="#servicos" className="text-gray-700 hover:text-blue-900">Serviços</a>
            <a href="#cursos" className="text-gray-700 hover:text-blue-900">Cursos</a>
            <a href="#sobre" className="text-gray-700 hover:text-blue-900">Sobre Nós</a>
            <a href="#contato" className="text-gray-700 hover:text-blue-900">Contato</a>
          </div>

          <button 
            className="md:hidden"
            onClick={() => setIsOpen(!isOpen)}
          >
            <Menu className="h-6 w-6 text-gray-700" />
          </button>
        </div>

        {isOpen && (
          <div className="md:hidden py-4">
            <a href="#servicos" className="block py-2 text-gray-700 hover:text-blue-900">Serviços</a>
            <a href="#cursos" className="block py-2 text-gray-700 hover:text-blue-900">Cursos</a>
            <a href="#sobre" className="block py-2 text-gray-700 hover:text-blue-900">Sobre Nós</a>
            <a href="#contato" className="block py-2 text-gray-700 hover:text-blue-900">Contato</a>
          </div>
        )}
      </div>
    </nav>
  );
}