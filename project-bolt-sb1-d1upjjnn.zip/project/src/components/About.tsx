import React from 'react';

export default function About() {
  return (
    <section id="sobre" className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold text-center mb-12">Sobre Nós</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
          <div className="rounded-lg overflow-hidden">
            <img 
              src="https://images.unsplash.com/photo-1589829545856-d10d557cf95f?auto=format&fit=crop&q=80&w=800"
              alt="Escritório"
              className="w-full h-[400px] object-cover"
            />
          </div>
          <div className="space-y-6">
            <h3 className="text-2xl font-bold text-blue-900">Nosso Escritório</h3>
            <p className="text-gray-600 text-lg">
              Somos um escritório especializado em diversas áreas do direito, com foco em proporcionar 
              soluções jurídicas eficientes e personalizadas. Nossa equipe de advogados possui vasta 
              experiência e está sempre atualizada com as últimas mudanças na legislação.
            </p>
            <p className="text-gray-600 text-lg">
              Nosso compromisso é oferecer um atendimento humanizado e de qualidade, buscando sempre 
              os melhores resultados para nossos clientes.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}