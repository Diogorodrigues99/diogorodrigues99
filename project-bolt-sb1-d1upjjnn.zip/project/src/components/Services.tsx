import React from 'react';
import { Scale, Gavel, Briefcase } from 'lucide-react';

export default function Services() {
  const services = [
    {
      icon: Scale,
      title: 'Direito Previdenciário',
      description: 'Atuação em aposentadorias, pensões e benefícios.'
    },
    {
      icon: Gavel,
      title: 'Direito Civil',
      description: 'Contratos, indenizações e questões familiares.'
    },
    {
      icon: Briefcase,
      title: 'Direito Trabalhista',
      description: 'Defesa dos direitos do trabalhador.'
    }
  ];

  return (
    <section id="servicos" className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold text-center mb-12">Nossos Serviços</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <div key={index} className="bg-white rounded-lg shadow-lg p-8 transform transition-all duration-300 hover:-translate-y-2">
              <service.icon className="w-12 h-12 text-blue-900 mx-auto mb-6" />
              <h3 className="text-xl font-semibold text-center mb-4">{service.title}</h3>
              <p className="text-gray-600 text-center">{service.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}