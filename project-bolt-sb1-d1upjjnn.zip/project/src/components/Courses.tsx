import React from 'react';

export default function Courses() {
  return (
    <section id="cursos" className="py-16 bg-gray-50">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold text-center mb-12">Cursos Jurídicos</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
          <div className="rounded-lg overflow-hidden">
            <img 
              src="https://images.unsplash.com/photo-1589391886645-d51941baf7fb?auto=format&fit=crop&q=80&w=800"
              alt="Cursos Jurídicos"
              className="w-full h-[400px] object-cover"
            />
          </div>
          <div className="space-y-6">
            <h3 className="text-2xl font-bold text-blue-900">Aprenda com Especialistas</h3>
            <p className="text-gray-600 text-lg">
              Oferecemos cursos online e presenciais sobre direito previdenciário, civil e trabalhista.
              Aprenda com profissionais experientes e atualizados com as últimas mudanças na legislação.
            </p>
            <a 
              href="https://pay.kiwify.com.br/aIRCNfC" 
              target="_blank" 
              rel="noopener noreferrer" 
              className="inline-block bg-blue-900 text-white px-8 py-3 rounded-lg hover:bg-blue-800 transition-colors"
            >
              Comprar Curso
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}